"""Genetic Algorithm for the Maximizing Ones (OneMax) problem.

Chromosome : list of L bits.   Fitness : number of ones.
Selection  : tournament (size k).  Crossover : single point.
Mutation   : bit flip.  Replacement : generational with elitism.
"""
import random
import statistics

# ---------------- parameters ----------------
L = 20            # chromosome length (number of genes)
POP = 30          # population size
GENS = 40         # maximum number of generations
PC = 0.8          # crossover probability
PM = 1.0 / L      # per-gene mutation probability
K = 3             # tournament size
ELITE = 1         # number of elite individuals copied unchanged
SEED = 42

def fitness(ch):                       # f(x) = number of ones
    return sum(ch)

def init_population():
    return [[random.randint(0, 1) for _ in range(L)] for _ in range(POP)]

def tournament(pop, fits):
    idx = random.sample(range(len(pop)), K)           # pick K at random
    best = max(idx, key=lambda i: fits[i])            # fittest of them wins
    return pop[best][:]

def single_point(p1, p2):
    if random.random() < PC:
        cut = random.randint(1, L - 1)                # cut point 1..L-1
        return p1[:cut] + p2[cut:], p2[:cut] + p1[cut:]
    return p1[:], p2[:]

def mutate(ch):
    return [1 - g if random.random() < PM else g for g in ch]

def run():
    random.seed(SEED)
    pop = init_population()
    history = []
    for gen in range(GENS + 1):
        fits = [fitness(c) for c in pop]
        best = max(fits)
        history.append((gen, best, statistics.mean(fits)))
        if best == L:                                 # optimum found, stop
            break
        order = sorted(range(POP), key=lambda i: fits[i], reverse=True)
        new = [pop[i][:] for i in order[:ELITE]]      # elitism
        while len(new) < POP:
            c1, c2 = single_point(tournament(pop, fits), tournament(pop, fits))
            new.extend([mutate(c1), mutate(c2)])
        pop = new[:POP]
    fits = [fitness(c) for c in pop]
    b = max(range(POP), key=lambda i: fits[i])
    return pop[b], fits[b], history

if __name__ == "__main__":
    best, f, hist = run()
    print(f"L={L}, population={POP}, Pc={PC}, Pm={PM:.2f}, tournament k={K}, elitism={ELITE}, seed={SEED}")
    print("Gen  Best  Average")
    for g, b, a in hist:
        if g % 2 == 0 or g == hist[-1][0]:
            print(f"{g:3d}  {b:4d}  {a:7.2f}")
    print("Best chromosome:", "".join(map(str, best)))
    print("Best fitness   :", f, "/", L, " (found in generation", hist[-1][0], ")")
