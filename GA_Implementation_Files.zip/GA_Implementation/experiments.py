import random, statistics, ga_onemax as G, json
def trial(seed,pm=None,pop=None,gens=200):
    G.SEED=seed
    if pm is not None: G.PM=pm
    if pop is not None: G.POP=pop
    G.GENS=gens
    b,f,h=G.run(); return h[-1][0], f
out={}
print("Mutation rate experiment (L=20,pop=30,200 gen cap,30 seeds)")
for pm in [0.0,0.01,0.05,0.2,0.5]:
    r=[trial(s,pm=pm,pop=30) for s in range(1,31)]
    ok=[g for g,f in r if f==20]; 
    print(f"Pm={pm:<5} solved {len(ok)}/30  mean gens (solved) {statistics.mean(ok) if ok else float('nan'):.1f}  mean final best {statistics.mean(f for g,f in r):.2f}")
print("Population size experiment (Pm=0.05)")
for pop in [10,20,30,60,100]:
    r=[trial(s,pm=0.05,pop=pop) for s in range(1,31)]
    ok=[g for g,f in r if f==20]
    print(f"POP={pop:<4} solved {len(ok)}/30  mean gens {statistics.mean(ok):.1f}  mean evaluations {statistics.mean(ok)*pop:.0f}")
