"""Hand-traceable worked example: OneMax, 8 bits, population 6.
All random draws are FIXED and listed so the report tables can be reproduced."""
pop = ["10110010","01001101","11100110","00011001","10101011","01110100"]
fit = lambda s: s.count("1")
f = [fit(s) for s in pop]; tot = sum(f)
print("Gen0:", list(zip(pop, f)), "sum", tot, "avg", tot/6)
# roulette wheel
cum=[]; c=0
for x in f: c+=x/tot; cum.append(round(c,4))
print("prob", [round(x/tot,4) for x in f]); print("cum", cum)
spins=[0.15,0.62,0.48,0.91]   # fixed spins -> 4 parents
def pick(r):
    for i,cv in enumerate(cum):
        if r<=cv: return i
par=[pick(r) for r in spins]; print("parents idx", par, [pop[i] for i in par])
# crossover: (P1,P2) cut 3 ; (P3,P4) cut 5
def xo(a,b,k): return a[:k]+b[k:], b[:k]+a[k:]
c1,c2=xo(pop[par[0]],pop[par[1]],3); c3,c4=xo(pop[par[2]],pop[par[3]],5)
print("children", c1,c2,c3,c4)
# mutation: flip positions (1-indexed) c1:{6}, c2:{}, c3:{2}, c4:{}
def flip(s,pos):
    l=list(s)
    for p in pos: l[p-1]='1' if l[p-1]=='0' else '0'
    return "".join(l)
m=[flip(c1,[6]),c2,flip(c3,[2]),c4]; print("mutated", m, [fit(x) for x in m])
# elitism: keep 2 best of old pop
order=sorted(range(6),key=lambda i:-f[i]); elite=[pop[i] for i in order[:2]]
print("elite", elite,[fit(x) for x in elite])
new=elite+m; nf=[fit(x) for x in new]; print("Gen1", list(zip(new,nf)), "sum",sum(nf),"avg",sum(nf)/6)
