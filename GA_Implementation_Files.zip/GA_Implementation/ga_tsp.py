"""GA for a 10-city Traveling Salesman Problem (delivery route), checked against brute force."""
import random, math, itertools, statistics, json
CITIES = {"A":(2,3),"B":(8,1),"C":(14,5),"D":(17,12),"E":(12,16),"F":(6,14),"G":(1,10),"H":(9,8),"I":(15,2),"J":(5,6)}
names = list(CITIES); N = len(names)
def dist(a,b): return math.dist(CITIES[a],CITIES[b])
def tour_len(t): return sum(dist(t[i],t[(i+1)%N]) for i in range(N))
POP, GENS, PC, PM, K, ELITE = 60, 150, 0.9, 0.2, 3, 2
def order_crossover(p1,p2):
    a,b = sorted(random.sample(range(N),2))
    child = [None]*N; child[a:b+1] = p1[a:b+1]
    fill = [g for g in p2 if g not in child]
    for i in range(N):
        if child[i] is None: child[i] = fill.pop(0)
    return child
def swap_mut(t):
    t=t[:]
    if random.random()<PM:
        i,j=random.sample(range(N),2); t[i],t[j]=t[j],t[i]
    return t
def tourn(pop):
    return min(random.sample(pop,K), key=tour_len)[:]
def run(seed):
    random.seed(seed)
    pop=[random.sample(names,N) for _ in range(POP)]
    hist=[]
    for g in range(GENS+1):
        pop.sort(key=tour_len); hist.append(tour_len(pop[0]))
        new=[p[:] for p in pop[:ELITE]]
        while len(new)<POP:
            p1,p2=tourn(pop),tourn(pop)
            c1,c2=(order_crossover(p1,p2),order_crossover(p2,p1)) if random.random()<PC else (p1,p2)
            new += [swap_mut(c1),swap_mut(c2)]
        pop=new[:POP]
    pop.sort(key=tour_len); return pop[0],tour_len(pop[0]),hist
# brute force (fix A first, halve by symmetry)
best=None;bl=1e9
for perm in itertools.permutations(names[1:]):
    if perm[0]>perm[-1]: continue
    t=[names[0]]+list(perm); l=tour_len(t)
    if l<bl: bl,best=l,t
random.seed(1); rand=statistics.mean(tour_len(random.sample(names,N)) for _ in range(1000))
# nearest neighbour from A
t=["A"]; rem=set(names[1:])
while rem:
    n=min(rem,key=lambda c:dist(t[-1],c)); t.append(n); rem.remove(n)
nn=tour_len(t)
res=[run(s) for s in range(1,11)]
lens=[r[1] for r in res]
out=dict(brute=bl,brute_tour=best,nn=nn,nn_tour=t,rand=rand,ga_lens=lens,ga_best_tour=min(res,key=lambda r:r[1])[0],
         hist=[r[2] for r in res])
json.dump(out,open("tsp_results.json","w"))
print("Brute-force optimum: %.3f  %s"%(bl,"-".join(best)))
print("Nearest neighbour  : %.3f  %s"%(nn,"-".join(t)))
print("Random tour (mean of 1000): %.3f"%rand)
print("GA, 10 seeds, best lengths:",[round(x,3) for x in lens])
print("GA best %.3f mean %.3f worst %.3f ; seeds reaching optimum: %d/10"%(min(lens),statistics.mean(lens),max(lens),sum(abs(x-bl)<1e-9 for x in lens)))
print("GA best tour:","-".join(out["ga_best_tour"]))
